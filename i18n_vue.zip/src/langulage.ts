class Language{
    public language:string="fr";
    public setLanguage(language:string){
      this.language = language
    }
  }
  const ln = new Language();
 export default ln;  